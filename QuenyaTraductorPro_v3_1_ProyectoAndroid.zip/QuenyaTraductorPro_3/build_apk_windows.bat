@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle no esta en PATH.
  echo Abre este proyecto en Android Studio y usa Build ^> Build APK(s).
  pause
  exit /b 1
)
gradle --version
if errorlevel 1 exit /b 1
gradle assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK generado en: app\build\outputs\apk\debug\app-debug.apk
pause
