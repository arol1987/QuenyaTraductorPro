# Quenya Traductor Pro 3.1 — proyecto Android

Este ZIP contiene el código fuente del prototipo Android. **No contiene un APK compilado**: la compilación requiere Android SDK y Gradle, que no están disponibles en el entorno donde se preparó este paquete.

## Crear el APK (método recomendado)

1. En una computadora, instala Android Studio desde la web oficial: https://developer.android.com/studio.
2. Abre Android Studio y permite instalar Android SDK Platform 35 y las herramientas de compilación que solicite.
3. Descomprime este ZIP. En Android Studio selecciona **Open** y elige la carpeta `QuenyaTraductorPro_3` (la que contiene `settings.gradle`).
4. Espera a que termine la sincronización de Gradle. Acepta la instalación de los componentes que Android Studio solicite.
5. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Al terminar, pulsa **Locate** en la notificación de compilación. El APK de prueba normalmente queda en `app/build/outputs/apk/debug/app-debug.apk`.
7. Copia el APK al teléfono Android, ábrelo y autoriza la instalación desde esa fuente si Android lo solicita.

## Alternativa por terminal

Se necesita tener Android SDK instalado y `gradle` disponible en el PATH. En Windows ejecuta `build_apk_windows.bat`; en macOS/Linux ejecuta `./build_apk_linux_mac.sh`. Android Studio es la vía recomendada porque este paquete no incluye el wrapper de Gradle.

## Qué incluye

- Interfaz web local integrada en una aplicación Android mediante WebView.
- Glosario básico integrado para consultas orientativas y funciones de favoritos/lectura que ofrece el prototipo.
- Consulta online mediante enlaces de búsqueda; no descarga ni verifica automáticamente las páginas y no equivale a un motor de traducción automática.

## Limitaciones importantes

El quenya es una lengua construida cuyo vocabulario y gramática fueron revisados por Tolkien durante décadas. Las fuentes pueden presentar formas de épocas diferentes y algunas formas neo-quenya son propuestas de autores modernos. Por eso, el prototipo no puede garantizar traducciones correctas de frases libres. Para un diccionario amplio, conviene consultar Eldamo y distinguir las formas documentadas de las propuestas neo-quenya: https://eldamo.org/content/language-pages/lang-q.html.

## Enlaces de referencia

- Android Studio: https://developer.android.com/studio
- Guía oficial de compilación de APK: https://developer.android.com/build/building-cmdline
- Eldamo, Quenya: https://eldamo.org/content/language-pages/lang-q.html
