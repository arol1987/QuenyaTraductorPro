package com.quenya.traductor
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.WebSettings
class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val web=WebView(this)
  web.settings.javaScriptEnabled=true
  web.settings.domStorageEnabled=true
  web.settings.cacheMode=WebSettings.LOAD_DEFAULT
  web.webViewClient=WebViewClient()
  web.webChromeClient=WebChromeClient()
  web.loadUrl("file:///android_asset/index.html")
  setContentView(web)
 }
}