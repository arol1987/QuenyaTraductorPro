#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle no está instalado o no está en PATH." >&2
  echo "Abre el proyecto en Android Studio y usa Build > Build APK(s)." >&2
  exit 1
fi
gradle assembleDebug
echo "APK generado en: app/build/outputs/apk/debug/app-debug.apk"
